package com.aienhancer.app

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlin.coroutines.coroutineContext
import kotlin.math.min
import kotlin.math.roundToInt

private const val SCALE = 4
private const val OVERLAP = 16

@Composable
fun EnhanceScreen(uri: Uri, onBack: () -> Unit) {
    val context = LocalContext.current
    val settings = remember { SettingsStore.load(context) }
    // Качественная модель — только если она реально есть в APK
    val useQuality = remember {
        settings.model == EnhancerSettings.MODEL_QUALITY &&
            ONNXModelRunner.isAvailable(context, ONNXModelRunner.QUALITY_MODEL)
    }

    var original by remember { mutableStateOf<Bitmap?>(null) }
    var enhanced by remember { mutableStateOf<Bitmap?>(null) }
    var progress by remember { mutableFloatStateOf(0f) }
    var error by remember { mutableStateOf<String?>(null) }
    var strength by remember { mutableFloatStateOf(settings.defaultStrength) }
    var brightness by remember { mutableFloatStateOf(0f) }
    var contrast by remember { mutableFloatStateOf(1f) }
    var saturation by remember { mutableFloatStateOf(1f) }
    var showAdjust by remember { mutableStateOf(false) }
    var passes by remember { mutableIntStateOf(settings.passes) }
    var saving by remember { mutableStateOf(false) }
    var savedUri by remember { mutableStateOf<Uri?>(null) }
    var runId by remember { mutableIntStateOf(0) }
    var saveTrigger by remember { mutableIntStateOf(0) }

    // Загрузка фото + улучшение. Отменяется автоматически, если экран закрыли.
    // Перезапускается при «Повторить» (runId) и при «Усилить ещё» (passes).
    LaunchedEffect(uri, runId, passes) {
        error = null
        enhanced = null
        original = null
        savedUri = null
        progress = 0f
        val currentPasses = if (useQuality) 1 else passes
        try {
            val result = withContext(Dispatchers.Default) {
                val job = coroutineContext[Job]
                val src = ImageUtils.loadBitmap(
                    context,
                    uri,
                    ImageUtils.maxInputSideFor(
                        SCALE,
                        if (useQuality) min(settings.maxOutputSide, 2048) else settings.maxOutputSide
                    )
                )
                original = src
                createRunner(context, useQuality).use { runner ->
                    val tileSz = runner.tileCore(OVERLAP)
                    var current: Bitmap = ImageUtils.processInTiles(
                        source = src,
                        scale = runner.scale,
                        tileSize = tileSz,
                        overlap = OVERLAP,
                        onProgress = { progress = if (currentPasses >= 2) it / 2f else it }
                    ) { t ->
                        job?.ensureActive()
                        runner.run(t)
                    }
                    if (currentPasses >= 2) {
                        // Второй проход: уменьшаем результат обратно до размера оригинала
                        // и прогоняем через модель ещё раз.
                        val small = downscaleTo(current, src.width, src.height)
                        if (small !== current) current.recycle()
                        current = ImageUtils.processInTiles(
                            source = small,
                            scale = runner.scale,
                            tileSize = tileSz,
                            overlap = OVERLAP,
                            onProgress = { progress = 0.5f + it / 2f }
                        ) { t ->
                            job?.ensureActive()
                            runner.run(t)
                        }
                        small.recycle()
                    }
                    current
                }
            }
            enhanced = result
        } catch (e: CancellationException) {
            throw e
        } catch (e: OutOfMemoryError) {
            error = "Не хватило памяти. Выбери размер поменьше в настройках или фото поменьше."
        } catch (e: Throwable) {
            error = e.localizedMessage ?: e.javaClass.simpleName
        }
    }

    // Сохранение. Запускается через saveTrigger (в т.ч. после выдачи разрешения).
    LaunchedEffect(saveTrigger) {
        if (saveTrigger == 0) return@LaunchedEffect
        val o = original ?: return@LaunchedEffect
        val e = enhanced ?: return@LaunchedEffect
        saving = true
        try {
            val s = strength
            val adj = Adjustments(brightness, contrast, saturation)
            val cfg = settings
            val saved = withContext(Dispatchers.Default) {
                val adjusted = ImageUtils.applyAdjustments(e, adj)
                try {
                    val out = ImageUtils.blend(o, adjusted, s)
                    try {
                        saveToGallery(context, out, cfg)
                    } finally {
                        out.recycle()
                    }
                } finally {
                    if (adjusted !== e) adjusted.recycle()
                }
            }
            savedUri = saved
            Toast.makeText(context, "Сохранено в Pictures/AIPhotoEnhancer", Toast.LENGTH_LONG).show()
        } catch (ex: Throwable) {
            Toast.makeText(
                context,
                "Не удалось сохранить: ${ex.localizedMessage ?: ex.javaClass.simpleName}",
                Toast.LENGTH_LONG
            ).show()
        } finally {
            saving = false
        }
    }

    // На Android 8–9 для записи в галерею нужно разрешение
    val storagePermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) saveTrigger++
        else Toast.makeText(context, "Без разрешения сохранить нельзя", Toast.LENGTH_SHORT).show()
    }

    val onSave: () -> Unit = {
        val needPermission = Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(
                context, Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED
        if (needPermission) storagePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        else saveTrigger++
    }

    val onShare: () -> Unit = {
        val u = savedUri
        if (u != null) {
            try {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "image/*"
                    putExtra(Intent.EXTRA_STREAM, u)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(send, "Поделиться фото"))
            } catch (ex: Throwable) {
                Toast.makeText(context, "Не удалось поделиться", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Любое изменение ползунков делает прошлое сохранение «устаревшим»
    val touch: () -> Unit = { savedUri = null }

    val orig = original
    val enh = enhanced
    val processing = error == null && enh == null
    val adjustments = Adjustments(brightness, contrast, saturation)
    val buttonPadding = PaddingValues(horizontal = 8.dp)

    Column(
        Modifier.fillMaxSize().background(Color.Black).systemBarsPadding(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            when {
                error != null -> Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Text("Не удалось улучшить фото", color = Color.White, fontSize = 18.sp)
                    Text(
                        error ?: "",
                        color = Color(0xFFBBBBBB),
                        fontSize = 13.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                    Button(onClick = { runId++ }, modifier = Modifier.padding(top = 16.dp)) {
                        Text("Повторить")
                    }
                }
                orig != null -> BeforeAfter(orig, enh, strength, adjustments)
                else -> Text("Открываю фото…", color = Color.White)
            }
        }

        if (processing && orig != null) {
            val stageText = if (passes >= 2 && !useQuality) {
                "  •  проход ${if (progress < 0.5f) 1 else 2} из 2"
            } else ""
            Text(
                "Улучшаю… ${(progress * 100).roundToInt()}%$stageText",
                color = Color.White,
                modifier = Modifier.padding(top = 8.dp)
            )
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp)
            )
            if (useQuality) {
                Text(
                    "Качественная модель работает медленно — это нормально",
                    color = Color(0xFFAAAAAA),
                    fontSize = 12.sp
                )
            }
        }

        if (enh != null) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .heightIn(max = 240.dp)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "Сила улучшения: ${(strength * 100).roundToInt()}%   •   ${enh.width} × ${enh.height}",
                    color = Color.White,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(top = 8.dp)
                )
                Slider(
                    value = strength,
                    onValueChange = {
                        strength = it
                        touch()
                    }
                )

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { showAdjust = !showAdjust },
                        modifier = Modifier.weight(1f),
                        contentPadding = buttonPadding
                    ) {
                        Text(if (showAdjust) "Свет и цвет ▲" else "Свет и цвет ▼", fontSize = 13.sp, maxLines = 1)
                    }
                    if (passes < 2 && !useQuality) {
                        OutlinedButton(
                            onClick = { passes = 2 },
                            modifier = Modifier.weight(1f),
                            contentPadding = buttonPadding
                        ) {
                            Text("Усилить ещё", fontSize = 13.sp, maxLines = 1)
                        }
                    }
                }

                if (showAdjust) {
                    AdjustSlider("Яркость", "${(brightness * 100).roundToInt()}", brightness, -0.3f..0.3f) {
                        brightness = it
                        touch()
                    }
                    AdjustSlider("Контраст", "${(contrast * 100).roundToInt()}%", contrast, 0.7f..1.4f) {
                        contrast = it
                        touch()
                    }
                    AdjustSlider("Насыщенность", "${(saturation * 100).roundToInt()}%", saturation, 0f..2f) {
                        saturation = it
                        touch()
                    }
                    TextButton(onClick = {
                        brightness = 0f
                        contrast = 1f
                        saturation = 1f
                        touch()
                    }) {
                        Text("Сбросить свет и цвет", color = Color.White)
                    }
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = onBack,
                modifier = Modifier.weight(1f),
                contentPadding = buttonPadding
            ) {
                Text("Назад", maxLines = 1)
            }
            Button(
                onClick = onSave,
                enabled = enh != null && !saving,
                modifier = Modifier.weight(1f),
                contentPadding = buttonPadding
            ) {
                Text(if (saving) "Сохраняю…" else "Сохранить", maxLines = 1)
            }
            OutlinedButton(
                onClick = onShare,
                enabled = savedUri != null,
                modifier = Modifier.weight(1f),
                contentPadding = buttonPadding
            ) {
                Text("Поделиться", maxLines = 1)
            }
        }
    }
}

@Composable
private fun AdjustSlider(
    label: String,
    display: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit
) {
    Text(
        "$label: $display",
        color = Color.White,
        fontSize = 13.sp,
        modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
    )
    Slider(value = value, onValueChange = onChange, valueRange = range)
}

/**
 * Сравнение До/После: слева оригинал, справа улучшенное (с учётом силы и подстройки света/цвета).
 * Разделитель можно двигать пальцем. Пока улучшенного нет — показывается только оригинал.
 */
@Composable
private fun BeforeAfter(
    original: Bitmap,
    enhanced: Bitmap?,
    strength: Float,
    adjustments: Adjustments
) {
    val origImage = remember(original) { original.asImageBitmap() }
    val enhImage = remember(enhanced) { enhanced?.asImageBitmap() }
    val filter = remember(adjustments) {
        if (adjustments.isDefault) null
        else ColorFilter.colorMatrix(ColorMatrix(adjustments.toMatrix()))
    }
    var divider by remember { mutableFloatStateOf(0.5f) }

    Box(Modifier.fillMaxSize()) {
        Canvas(
            Modifier
                .fillMaxSize()
                .pointerInput(enhImage) {
                    if (enhImage == null) return@pointerInput
                    detectHorizontalDragGestures(
                        onDragStart = { divider = (it.x / size.width).coerceIn(0f, 1f) }
                    ) { change, _ ->
                        divider = (change.position.x / size.width).coerceIn(0f, 1f)
                    }
                }
        ) {
            // Размер по пропорциям оригинала (улучшенное в 4 раза больше, пропорции те же)
            val iw = original.width.toFloat()
            val ih = original.height.toFloat()
            val fit = min(size.width / iw, size.height / ih)
            val dw = (iw * fit).roundToInt()
            val dh = (ih * fit).roundToInt()
            val dstOffset = IntOffset(
                ((size.width - dw) / 2f).roundToInt(),
                ((size.height - dh) / 2f).roundToInt()
            )
            val dstSize = IntSize(dw, dh)

            drawImage(
                image = origImage,
                dstOffset = dstOffset,
                dstSize = dstSize,
                filterQuality = FilterQuality.High
            )

            if (enhImage != null) {
                val splitX = size.width * divider
                clipRect(left = splitX, right = size.width) {
                    drawImage(
                        image = enhImage,
                        dstOffset = dstOffset,
                        dstSize = dstSize,
                        alpha = strength.coerceIn(0f, 1f),
                        colorFilter = filter,
                        filterQuality = FilterQuality.High
                    )
                }
                drawLine(
                    color = Color.White,
                    start = Offset(splitX, 0f),
                    end = Offset(splitX, size.height),
                    strokeWidth = 2.dp.toPx()
                )
                drawCircle(
                    color = Color.White,
                    radius = 14.dp.toPx(),
                    center = Offset(splitX, size.height / 2f)
                )
            }
        }

        if (enhImage != null) {
            Label("До", Modifier.align(Alignment.TopStart))
            Label("После", Modifier.align(Alignment.TopEnd))
        }
    }
}

@Composable
private fun Label(text: String, modifier: Modifier) {
    Box(
        modifier
            .padding(12.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0x99000000))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(text, color = Color.White, fontSize = 13.sp)
    }
}

/** Создаёт обработчик нужной модели. Для тяжёлой модели плитки меньше — меньше памяти. */
private fun createRunner(context: Context, quality: Boolean): ONNXModelRunner =
    if (quality) ONNXModelRunner(context, ONNXModelRunner.QUALITY_MODEL, 128)
    else ONNXModelRunner(context)

/** Уменьшает картинку до w x h ступенями «вдвое» — так меньше «лесенок», чем за один раз. */
private fun downscaleTo(bitmap: Bitmap, w: Int, h: Int): Bitmap {
    var cur = bitmap
    while (cur.width / 2 >= w && cur.height / 2 >= h) {
        val next = Bitmap.createScaledBitmap(cur, cur.width / 2, cur.height / 2, true)
        if (cur !== bitmap) cur.recycle()
        cur = next
    }
    val out = if (cur.width == w && cur.height == h) cur
    else Bitmap.createScaledBitmap(cur, w, h, true)
    if (cur !== bitmap && cur !== out) cur.recycle()
    return out
}

/** Сохраняет Bitmap в Pictures/AIPhotoEnhancer в формате из настроек (JPEG или PNG). */
private fun saveToGallery(context: Context, bitmap: Bitmap, settings: EnhancerSettings): Uri {
    val png = settings.saveFormat == EnhancerSettings.FORMAT_PNG
    val ext = if (png) "png" else "jpg"
    val mime = if (png) "image/png" else "image/jpeg"
    val format = if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG

    val values = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, "enhanced_${System.currentTimeMillis()}.$ext")
        put(MediaStore.Images.Media.MIME_TYPE, mime)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            put(
                MediaStore.Images.Media.RELATIVE_PATH,
                Environment.DIRECTORY_PICTURES + "/AIPhotoEnhancer"
            )
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
    }
    val resolver = context.contentResolver
    val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        ?: error("Галерея не приняла файл")
    try {
        val ok = resolver.openOutputStream(uri)?.use { bitmap.compress(format, settings.jpegQuality, it) }
            ?: error("Не удалось открыть файл для записи")
        check(ok) { "Не удалось закодировать изображение" }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
        }
    } catch (e: Throwable) {
        resolver.delete(uri, null, null)
        throw e
    }
    return uri
}
