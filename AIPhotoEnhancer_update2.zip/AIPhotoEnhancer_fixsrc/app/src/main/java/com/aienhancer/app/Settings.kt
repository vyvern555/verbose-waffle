package com.aienhancer.app

import android.content.Context

/** Настройки приложения, которые пользователь меняет в экране «Настройки». */
data class EnhancerSettings(
    /** С какой силой улучшения открывается результат (0..1). */
    val defaultStrength: Float = 1f,
    /** 1 — обычный режим, 2 — усиленный (модель прогоняется дважды). */
    val passes: Int = 1,
    /** MODEL_FAST (быстрая) или MODEL_QUALITY (качественная, медленная). */
    val model: Int = MODEL_FAST,
    /** Максимальная сторона результата в пикселях. */
    val maxOutputSide: Int = 4096,
    /** FORMAT_JPEG или FORMAT_PNG. */
    val saveFormat: Int = FORMAT_JPEG,
    /** Качество JPEG, 70..100. */
    val jpegQuality: Int = 95
) {
    companion object {
        const val FORMAT_JPEG = 0
        const val FORMAT_PNG = 1
        const val MODEL_FAST = 0
        const val MODEL_QUALITY = 1
    }
}

/** Хранение настроек в SharedPreferences. */
object SettingsStore {
    private const val PREFS = "enhancer_settings"
    private const val K_STRENGTH = "default_strength"
    private const val K_PASSES = "passes"
    private const val K_MODEL = "model"
    private const val K_MAX_SIDE = "max_output_side"
    private const val K_FORMAT = "save_format"
    private const val K_QUALITY = "jpeg_quality"

    fun load(context: Context): EnhancerSettings {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val d = EnhancerSettings()
        return EnhancerSettings(
            defaultStrength = p.getFloat(K_STRENGTH, d.defaultStrength).coerceIn(0f, 1f),
            passes = p.getInt(K_PASSES, d.passes).coerceIn(1, 2),
            model = p.getInt(K_MODEL, d.model).coerceIn(0, 1),
            maxOutputSide = p.getInt(K_MAX_SIDE, d.maxOutputSide).coerceIn(1024, 4096),
            saveFormat = p.getInt(K_FORMAT, d.saveFormat),
            jpegQuality = p.getInt(K_QUALITY, d.jpegQuality).coerceIn(50, 100)
        )
    }

    fun save(context: Context, s: EnhancerSettings) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putFloat(K_STRENGTH, s.defaultStrength)
            .putInt(K_PASSES, s.passes)
            .putInt(K_MODEL, s.model)
            .putInt(K_MAX_SIDE, s.maxOutputSide)
            .putInt(K_FORMAT, s.saveFormat)
            .putInt(K_QUALITY, s.jpegQuality)
            .apply()
    }
}
