package com.aienhancer.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var s by remember { mutableStateOf(SettingsStore.load(context)) }
    val qualityAvailable = remember {
        ONNXModelRunner.isAvailable(context, ONNXModelRunner.QUALITY_MODEL)
    }
    val update: (EnhancerSettings) -> Unit = { new ->
        s = new
        SettingsStore.save(context, new)
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .systemBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        TextButton(onClick = onBack) { Text("← Назад", color = Color.White) }
        Text("Настройки", color = Color.White, fontSize = 24.sp, modifier = Modifier.padding(bottom = 8.dp))

        SectionTitle("Сила улучшения по умолчанию: ${(s.defaultStrength * 100).roundToInt()}%")
        Slider(
            value = s.defaultStrength,
            onValueChange = { update(s.copy(defaultStrength = it)) }
        )
        Hint("С такой силой открывается результат. Потом её можно менять ползунком на экране фото.")

        SectionTitle("Нейросеть")
        OptionRow("Быстрая — Real-ESRGAN general v3", s.model == EnhancerSettings.MODEL_FAST) {
            update(s.copy(model = EnhancerSettings.MODEL_FAST))
        }
        OptionRow(
            if (qualityAvailable) "Качественная — Real-ESRGAN x4plus (медленно, больше деталей)"
            else "Качественная — не найдена в этой сборке",
            s.model == EnhancerSettings.MODEL_QUALITY
        ) {
            if (qualityAvailable) update(s.copy(model = EnhancerSettings.MODEL_QUALITY))
        }
        Hint("Качественная модель в разы тяжелее: фото обрабатывается минуты, размер результата для неё ограничен 2048 px, а усиленный режим не используется.")

        SectionTitle("Режим обработки")
        OptionRow("Обычный — 1 проход (быстрее)", s.passes == 1) {
            update(s.copy(passes = 1))
        }
        OptionRow("Усиленный — 2 прохода (дольше, сильнее убирает шум)", s.passes == 2) {
            update(s.copy(passes = 2))
        }

        SectionTitle("Максимальный размер результата")
        val sizes = listOf(
            2048 to "2048 px — быстро, меньше памяти",
            3072 to "3072 px — баланс",
            4096 to "4096 px — максимум"
        )
        sizes.forEach { (value, label) ->
            OptionRow(label, s.maxOutputSide == value) {
                update(s.copy(maxOutputSide = value))
            }
        }
        Hint("Если телефон вылетает или пишет «не хватило памяти», выбери меньший размер.")

        SectionTitle("Формат сохранения")
        OptionRow("JPEG — меньше размер файла", s.saveFormat == EnhancerSettings.FORMAT_JPEG) {
            update(s.copy(saveFormat = EnhancerSettings.FORMAT_JPEG))
        }
        OptionRow("PNG — без потерь, файл больше", s.saveFormat == EnhancerSettings.FORMAT_PNG) {
            update(s.copy(saveFormat = EnhancerSettings.FORMAT_PNG))
        }

        if (s.saveFormat == EnhancerSettings.FORMAT_JPEG) {
            SectionTitle("Качество JPEG: ${s.jpegQuality}")
            Slider(
                value = s.jpegQuality.toFloat(),
                onValueChange = { update(s.copy(jpegQuality = it.roundToInt())) },
                valueRange = 70f..100f
            )
        }

        Button(
            onClick = { update(EnhancerSettings()) },
            modifier = Modifier.padding(top = 24.dp)
        ) {
            Text("Сбросить настройки")
        }
        Hint("Настройки применяются к следующему фото.")
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = Color.White, fontSize = 16.sp, modifier = Modifier.padding(top = 20.dp, bottom = 4.dp))
}

@Composable
private fun Hint(text: String) {
    Text(text, color = Color(0xFFAAAAAA), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
}

@Composable
private fun OptionRow(text: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Text(text, color = Color.White, fontSize = 15.sp)
    }
}
