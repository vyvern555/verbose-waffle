package com.aienhancer.app

import kotlin.math.abs

/**
 * Ручная подстройка картинки после улучшения.
 * brightness: -0.3..0.3 (0 — без изменений), contrast: 0.7..1.4 (1 — без изменений),
 * saturation: 0..2 (1 — без изменений).
 */
data class Adjustments(
    val brightness: Float = 0f,
    val contrast: Float = 1f,
    val saturation: Float = 1f
) {
    val isDefault: Boolean
        get() = abs(brightness) < 0.001f && abs(contrast - 1f) < 0.001f && abs(saturation - 1f) < 0.001f

    /** Матрица 4x5 (строками) для ColorMatrix: сначала насыщенность, потом контраст и яркость. */
    fun toMatrix(): FloatArray {
        val c = contrast
        val s = saturation
        val a = 1f - s
        val lr = 0.213f * a
        val lg = 0.715f * a
        val lb = 0.072f * a
        val t = 255f * (0.5f * (1f - c) + brightness)
        return floatArrayOf(
            c * (lr + s), c * lg, c * lb, 0f, t,
            c * lr, c * (lg + s), c * lb, 0f, t,
            c * lr, c * lg, c * (lb + s), 0f, t,
            0f, 0f, 0f, 1f, 0f
        )
    }
}
