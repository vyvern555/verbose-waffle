package com.aienhancer.app

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas

/**
 * Обёртка над ONNX Runtime для модели realesr-general-x4v3 (апскейл ×4).
 * Вход: NCHW float32 RGB 0..1, выход: то же, но в 4 раза больше по каждой стороне.
 */
class ONNXModelRunner(context: Context) : AutoCloseable {

    /** Во сколько раз модель увеличивает изображение. */
    val scale = 4

    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()
    private val session: OrtSession
    private val inputName: String

    /** Размер входа, если модель экспортирована с фиксированной формой; 0 — размер любой. */
    private val fixedH: Int
    private val fixedW: Int

    init {
        val bytes = context.assets.open(MODEL_PATH).use { it.readBytes() }
        val options = OrtSession.SessionOptions().apply {
            setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
            setIntraOpNumThreads(Runtime.getRuntime().availableProcessors().coerceIn(2, 6))
        }
        session = env.createSession(bytes, options)
        inputName = session.inputNames.first()
        val shape = (session.inputInfo[inputName]!!.info as TensorInfo).shape
        fixedH = shape.getOrNull(2)?.takeIf { it > 0 }?.toInt() ?: 0
        fixedW = shape.getOrNull(3)?.takeIf { it > 0 }?.toInt() ?: 0
    }

    /** Размер «ядра» плитки для processInTiles, чтобы плитка с запасом влезла во вход модели. */
    fun tileCore(overlap: Int): Int {
        return if (fixedH > 0 && fixedW > 0) {
            (minOf(fixedH, fixedW) - 2 * overlap).coerceAtLeast(32)
        } else {
            DEFAULT_TILE_CORE
        }
    }

    /** Прогоняет одну плитку. Возвращает Bitmap размером (w*scale) x (h*scale). */
    fun run(tile: Bitmap): Bitmap {
        val inW = tile.width
        val inH = tile.height

        // Для фиксированной формы дополняем плитку до нужного размера
        val padded = fixedH > 0 && fixedW > 0 && (inW != fixedW || inH != fixedH)
        val feed = if (padded) {
            require(inW <= fixedW && inH <= fixedH) { "Плитка больше входа модели" }
            Bitmap.createBitmap(fixedW, fixedH, Bitmap.Config.ARGB_8888).also {
                Canvas(it).drawBitmap(tile, 0f, 0f, null)
            }
        } else tile

        try {
            val buffer = ImageUtils.bitmapToFloatBuffer(feed)
            val shape = longArrayOf(1, 3, feed.height.toLong(), feed.width.toLong())
            val full: Bitmap = OnnxTensor.createTensor(env, buffer, shape).use { input ->
                session.run(mapOf(inputName to input)).use { result ->
                    val out = result.get(0) as OnnxTensor
                    val outShape = out.info.shape
                    val outH = outShape[2].toInt()
                    val outW = outShape[3].toInt()
                    check(outW == feed.width * scale && outH == feed.height * scale) {
                        "Неожиданный размер выхода модели: ${outW}x$outH"
                    }
                    ImageUtils.floatBufferToBitmap(out.floatBuffer, outW, outH)
                }
            }
            if (!padded) return full
            val cropped = Bitmap.createBitmap(full, 0, 0, inW * scale, inH * scale)
            if (cropped !== full) full.recycle()
            return cropped
        } finally {
            if (feed !== tile) feed.recycle()
        }
    }

    override fun close() {
        runCatching { session.close() }
    }

    companion object {
        private const val MODEL_PATH = "models/realesr-general-x4v3.onnx"
        private const val DEFAULT_TILE_CORE = 192
    }
}
